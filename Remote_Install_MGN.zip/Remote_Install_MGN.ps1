﻿$servers = Read-Host "Please enter server fqdn: "
$cred = Get-Credential



    try{
        If((Test-WSMan $server) -eq $true)
        {
            $session = New-PSSession -ComputerName $server -Credential $cred

            Copy-Item .\AwsReplicationWindowsInstaller.exe -Destination 'C:\' -ToSession $session
            Copy-Item .\InstallScript.ps1 -Destination 'C:\' -ToSession $session

            Invoke-Command -ScriptBlock {cd 'C:\'; .\InstallScript.ps1; } -Session $session

            $session | Remove-PSSession
        }else{
            Write-Host "WinRM is not enabled in $server"
        }
    }catch{
        Write-Host $_
    }